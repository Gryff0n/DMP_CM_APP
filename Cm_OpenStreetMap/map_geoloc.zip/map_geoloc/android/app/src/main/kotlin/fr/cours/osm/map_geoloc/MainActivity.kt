package fr.cours.osm.map_geoloc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
