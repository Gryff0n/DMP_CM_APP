// Exemple 2 : carte centrée sur la position de l'appareil (géolocalisation),
// avec boutons de zoom et bouton « recentrer ».
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

void main() => runApp(const MaterialApp(home: GeolocPage()));

/// Demande les autorisations puis renvoie la position courante.
/// Lève une exception avec un message lisible en cas de problème.
Future<LatLng> positionCourante() async {
  if (!await Geolocator.isLocationServiceEnabled()) {
    throw Exception('Le service de localisation est désactivé.');
  }
  var permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
  }
  if (permission == LocationPermission.denied) {
    throw Exception('Autorisation de localisation refusée.');
  }
  if (permission == LocationPermission.deniedForever) {
    throw Exception(
        'Autorisation refusée définitivement : modifiez-la dans les réglages.');
  }
  final p = await Geolocator.getCurrentPosition(
    locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
  );
  return LatLng(p.latitude, p.longitude);
}

class GeolocPage extends StatefulWidget {
  const GeolocPage({super.key});

  @override
  State<GeolocPage> createState() => _GeolocPageState();
}

class _GeolocPageState extends State<GeolocPage> {
  final MapController _controller = MapController();
  LatLng? _position; // null tant que la position n'est pas connue
  String? _erreur;
  StreamSubscription<Position>? _abonnement;

  @override
  void initState() {
    super.initState();
    _initialiser();
  }

  Future<void> _initialiser() async {
    try {
      final pos = await positionCourante();
      setState(() => _position = pos);
      // Suivi continu : le marqueur se déplace avec l'utilisateur
      // (nouvelle valeur tous les 10 m environ).
      _abonnement = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          distanceFilter: 10,
        ),
      ).listen((p) {
        setState(() => _position = LatLng(p.latitude, p.longitude));
      });
    } catch (e) {
      setState(() => _erreur = e.toString().replaceFirst('Exception: ', ''));
    }
  }

  @override
  void dispose() {
    _abonnement?.cancel();
    super.dispose();
  }

  void _zoomer(double delta) {
    final camera = _controller.camera;
    _controller.move(camera.center, (camera.zoom + delta).clamp(2.0, 19.0));
  }

  void _recentrer() {
    if (_position != null) _controller.move(_position!, 16);
  }

  @override
  Widget build(BuildContext context) {
    final Widget corps;
    if (_erreur != null) {
      corps = Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(_erreur!, textAlign: TextAlign.center),
        ),
      );
    } else if (_position == null) {
      corps = const Center(child: CircularProgressIndicator());
    } else {
      corps = FlutterMap(
        mapController: _controller,
        options: MapOptions(initialCenter: _position!, initialZoom: 16),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'net.eddbali.cours_osm.map_geoloc',
          ),
          MarkerLayer(
            markers: [
              Marker(
                point: _position!,
                width: 24,
                height: 24,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 3),
                  ),
                ),
              ),
            ],
          ),
          const RichAttributionWidget(
            attributions: [TextSourceAttribution('© OpenStreetMap contributors')],
          ),
        ],
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('OSM – ma position')),
      body: corps,
      floatingActionButton: _position == null
          ? null
          : Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                FloatingActionButton.small(
                  heroTag: 'plus',
                  onPressed: () => _zoomer(1),
                  child: const Icon(Icons.add),
                ),
                const SizedBox(height: 8),
                FloatingActionButton.small(
                  heroTag: 'moins',
                  onPressed: () => _zoomer(-1),
                  child: const Icon(Icons.remove),
                ),
                const SizedBox(height: 8),
                FloatingActionButton(
                  heroTag: 'recentrer',
                  onPressed: _recentrer,
                  child: const Icon(Icons.my_location),
                ),
              ],
            ),
    );
  }
}
