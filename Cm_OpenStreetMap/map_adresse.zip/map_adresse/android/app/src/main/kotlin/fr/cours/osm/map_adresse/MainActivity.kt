package fr.cours.osm.map_adresse

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
