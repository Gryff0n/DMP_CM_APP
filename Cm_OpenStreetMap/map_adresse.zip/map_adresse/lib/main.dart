// Exemple 3 : saisie d'une adresse, géocodage (Nominatim) et centrage de la
// carte. Si plusieurs lieux correspondent (ex. « Saint-Denis »), l'utilisateur
// choisit dans une liste.
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import 'geocodage.dart';

void main() => runApp(const MaterialApp(home: AdressePage()));

/// Zoom adapté à la nature du lieu trouvé.
double zoomPour(String type) => switch (type) {
      'country' => 5,
      'state' || 'region' => 7,
      'county' => 9,
      'city' || 'municipality' => 12,
      'town' || 'village' || 'suburb' => 14,
      'road' || 'street' => 16,
      _ => 17, // bâtiment, numéro de rue, commerce…
    };

class AdressePage extends StatefulWidget {
  const AdressePage({super.key});

  @override
  State<AdressePage> createState() => _AdressePageState();
}

class _AdressePageState extends State<AdressePage> {
  final MapController _controller = MapController();
  final TextEditingController _saisie = TextEditingController();
  Lieu? _lieu; // lieu actuellement affiché
  bool _enCours = false;

  @override
  void dispose() {
    _saisie.dispose();
    super.dispose();
  }

  Future<void> _rechercher() async {
    final texte = _saisie.text.trim();
    if (texte.isEmpty || _enCours) return;
    FocusScope.of(context).unfocus(); // ferme le clavier
    setState(() => _enCours = true);
    try {
      final lieux = await rechercherAdresse(texte);
      if (!mounted) return;
      if (lieux.isEmpty) {
        _message('Aucun résultat pour « $texte ».');
      } else if (lieux.length == 1) {
        _afficher(lieux.first);
      } else {
        final choix = await _choisir(lieux);
        if (choix != null) _afficher(choix);
      }
    } catch (e) {
      _message('Erreur : $e');
    } finally {
      if (mounted) setState(() => _enCours = false);
    }
  }

  /// Affiche la liste des propositions et renvoie celle choisie (ou null).
  Future<Lieu?> _choisir(List<Lieu> lieux) {
    return showModalBottomSheet<Lieu>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('${lieux.length} lieux trouvés',
                style: Theme.of(context).textTheme.titleMedium),
            Flexible(
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: lieux.length,
                separatorBuilder: (_, _) => const Divider(height: 1),
                itemBuilder: (context, i) => ListTile(
                  leading: const Icon(Icons.place_outlined),
                  title: Text(lieux[i].libelle),
                  subtitle: Text(lieux[i].type),
                  onTap: () => Navigator.pop(context, lieux[i]),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _afficher(Lieu lieu) {
    setState(() => _lieu = lieu);
    _controller.move(lieu.position, zoomPour(lieu.type));
  }

  void _message(String texte) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(texte)));
  }

  void _zoomer(double delta) {
    final camera = _controller.camera;
    _controller.move(camera.center, (camera.zoom + delta).clamp(2.0, 19.0));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('OSM – recherche d\'adresse')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              controller: _saisie,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _rechercher(),
              decoration: InputDecoration(
                hintText: 'Adresse, ville, lieu…',
                border: const OutlineInputBorder(),
                suffixIcon: _enCours
                    ? const Padding(
                        padding: EdgeInsets.all(12),
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : IconButton(
                        icon: const Icon(Icons.search),
                        onPressed: _rechercher,
                      ),
              ),
            ),
          ),
          if (_lieu != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(_lieu!.libelle,
                  maxLines: 2, overflow: TextOverflow.ellipsis),
            ),
          Expanded(
            child: FlutterMap(
              mapController: _controller,
              options: const MapOptions(
                // Département d'informatique de l'UO, avant toute recherche.
                initialCenter: LatLng(47.845665, 1.939773),
                initialZoom: 15,
              ),
              children: [
                TileLayer(
                  urlTemplate:
                      'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'net.eddbali.cours_osm.map_adresse',
                ),
                if (_lieu != null)
                  MarkerLayer(
                    markers: [
                      Marker(
                        point: _lieu!.position,
                        width: 40,
                        height: 40,
                        alignment: Alignment.topCenter,
                        child: const Icon(Icons.location_pin,
                            color: Colors.red, size: 40),
                      ),
                    ],
                  ),
                const RichAttributionWidget(
                  attributions: [
                    TextSourceAttribution('© OpenStreetMap contributors'),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton.small(
            heroTag: 'plus',
            onPressed: () => _zoomer(1),
            child: const Icon(Icons.add),
          ),
          const SizedBox(height: 8),
          FloatingActionButton.small(
            heroTag: 'moins',
            onPressed: () => _zoomer(-1),
            child: const Icon(Icons.remove),
          ),
        ],
      ),
    );
  }
}
