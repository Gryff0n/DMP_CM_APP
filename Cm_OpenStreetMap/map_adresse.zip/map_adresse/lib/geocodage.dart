// Géocodage d'une adresse via Nominatim (service de recherche d'OpenStreetMap).
// Politique d'usage : 1 requête/seconde maximum, User-Agent identifiant l'appli.
// Plus d'infos sur : https://operations.osmfoundation.org/policies/nominatim/
import 'dart:convert';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

/// Un résultat de recherche : un libellé lisible et des coordonnées.
class Lieu {
  final String libelle;
  final String type; // city, village, house, street…
  final LatLng position;

  const Lieu(this.libelle, this.type, this.position);

  factory Lieu.fromJson(Map<String, dynamic> json) => Lieu(
    json['display_name'] as String,
    (json['addresstype'] ?? json['type'] ?? '') as String,
    LatLng(
      double.parse(json['lat'] as String),
      double.parse(json['lon'] as String),
    ),
  );
}

/// Renvoie jusqu'à [limite] lieux correspondant au texte [adresse].
Future<List<Lieu>> rechercherAdresse(String adresse, {int limite = 8}) async {
  final uri = Uri.https('nominatim.openstreetmap.org', '/search', {
    'q': adresse,
    'format': 'jsonv2',
    'limit': '$limite',
    'accept-language': 'fr',
  });
  // Sur le Web, le navigateur impose son propre User-Agent (et un en-tête
  // personnalisé déclencherait une requête CORS préalable) : on ne l'ajoute
  // donc que sur les plateformes natives.
  final reponse = await http.get(
    uri,
    headers: kIsWeb
        ? null
        : {'User-Agent': 'net.eddbali.cours_osm.map_adresse/1.0'},
  );
  if (reponse.statusCode != 200) {
    throw Exception('Nominatim a répondu ${reponse.statusCode}');
  }
  final liste = jsonDecode(reponse.body) as List<dynamic>;
  return liste.map((e) => Lieu.fromJson(e as Map<String, dynamic>)).toList();
}
