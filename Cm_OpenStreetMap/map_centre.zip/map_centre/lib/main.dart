// Exemple 1 : carte OpenStreetMap centrée sur un point donné,
// avec boutons + et - pour zoomer / dézoomer.
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

void main() => runApp(const MaterialApp(home: CartePage()));

class CartePage extends StatefulWidget {
  const CartePage({super.key});

  @override
  State<CartePage> createState() => _CartePageState();
}

class _CartePageState extends State<CartePage> {
  // Point de centrage : département d'informatique de l'UO (Orléans).
  static const LatLng centre = LatLng(47.845665, 1.939773);

  // Le contrôleur permet de piloter la carte depuis le code.
  final MapController _controller = MapController();

  void _zoomer(double delta) {
    final camera = _controller.camera;
    final zoom = (camera.zoom + delta).clamp(2.0, 19.0);
    _controller.move(camera.center, zoom);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('OSM – point fixe')),
      body: FlutterMap(
        mapController: _controller,
        options: const MapOptions(
          initialCenter: centre,
          initialZoom: 15,
          minZoom: 2,
          maxZoom: 19,
        ),
        children: [
          // 1. Le fond de carte : des tuiles PNG 256×256 servies par OSM.
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'net.eddbali.cours_osm.map_centre',
          ),
          // 2. Un marqueur sur le point central.
          const MarkerLayer(
            markers: [
              Marker(
                point: centre,
                width: 40,
                height: 40,
                alignment: Alignment.topCenter,
                child: Icon(Icons.location_pin, color: Colors.red, size: 40),
              ),
            ],
          ),
          // 3. L'attribution, obligatoire (licence ODbL).
          const RichAttributionWidget(
            attributions: [TextSourceAttribution('© OpenStreetMap contributors')],
          ),
        ],
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton.small(
            heroTag: 'plus',
            onPressed: () => _zoomer(1),
            child: const Icon(Icons.add),
          ),
          const SizedBox(height: 8),
          FloatingActionButton.small(
            heroTag: 'moins',
            onPressed: () => _zoomer(-1),
            child: const Icon(Icons.remove),
          ),
        ],
      ),
    );
  }
}
