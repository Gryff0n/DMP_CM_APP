package fr.cours.osm.map_centre

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
